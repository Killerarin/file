# Hand-Gesture-Recognition-System
# Hand-Gestures  Adjusting the brightness of screen varies result.  try to position hand completely in the box and avoid arm or wrist coming in the box(as it will change the arearatio).  done using range values so may work for different color ranges for different people.
